function saveData(){
    onclick=window.open("edit-menu-item-status.html");
    //onclick="window.location.href="edit-menu-item-status.html"";
    //action="edit-menu-item-status.html";
    //alert("Hi");
    //return false;
}